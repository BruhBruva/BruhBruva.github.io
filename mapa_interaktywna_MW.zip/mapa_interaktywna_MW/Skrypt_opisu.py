# -*- coding: utf-8 -*-
"""
Created on Mon Oct 14 17:13:31 2024

@author: macko
"""

from docx import Document
from docx.shared import Inches
from docx.shared import Pt
from docx.enum.text import WD_PARAGRAPH_ALIGNMENT
import os

doc = Document()

from docx.oxml import OxmlElement
def set_font(paragraph, font_name='Arial', font_size=Pt(12), color='000000'):
    run = paragraph.add_run()
    run.font.name = font_name
    run.font.size = font_size
    run.font.color.rgb = color
    run.text = paragraph.text
    
def add_heading(text, level=2):
    heading = doc.add_heading(text, level=level)
    set_font(heading)

folder_path = '.'
screenshot_filename = 'zrzut_ekranu.png'
screenshot_path = os.path.join(folder_path, screenshot_filename)

doc.add_heading('Opis projektu: Mapa rodzajów rezerwatów przyrody w Polsce - Maciej Wisniewski', level=1)

doc.add_heading('Cel projektu', level=2)
doc.add_paragraph(
    "Celem tego projektu było stworzenie interaktywnej mapy, która wizualizuje różne typy rezerwatów "
    "przyrody w Polsce. W dobie zrównoważonego rozwoju i ochrony środowiska, coraz więcej osób "
    "interesuje się naturalnym dziedzictwem swojego kraju. Mapa ma na celu zwiększenie świadomości na "
    "temat różnych typów rezerwatów oraz ich lokalizacji. Dzięki niej użytkownik może w prosty sposób "
    "odkrywać miejsca, które warto odwiedzić, a także zrozumieć, jakie są rodzaje rezerwatów oraz jaką "
    "rolę odgrywają w ochronie przyrody."
)

doc.add_heading('Opis możliwości mapy', level=2)
doc.add_paragraph(
    "Mapa, którą stworzyłem, ma wiele przydatnych funkcji, które znacznie ułatwiają korzystanie z niej. "
    "Oto kilka kluczowych możliwości:\n\n"
    "1. Interaktywność: Mapa jest w pełni interaktywna, co oznacza, że użytkownicy mogą zbliżać i oddalać "
    "widok, a także przesuwać mapę, aby zobaczyć różne obszary Polski. Umożliwia to dokładne zapoznanie się "
    "z położeniem rezerwatów.\n\n"
    "2. Wielowarstwowość: Użytkownicy mają możliwość włączenia lub wyłączenia różnych typów rezerwatów "
    "przyrody. Każdy typ ma przypisany unikalny kolor, co ułatwia ich identyfikację. Można włączyć różne "
    "warstwy i zobaczyć, jak różne rodzaje rezerwatów współistnieją na tym samym obszarze.\n\n"
    "3. Informacje o rezerwatach: Po najechaniu na dany rezerwat pojawiają się dodatkowe informacje, "
    "takie jak nazwa rezerwatu oraz jego typ. To pozwala na szybkie uzyskanie informacji o każdym obiekcie "
    "bez potrzeby przeszukiwania internetu.\n\n"
    "4. Legendy i opisy: Mapa zawiera legendę, która wyjaśnia, jakie kolory odpowiadają poszczególnym typom "
    "rezerwatów. Dzięki temu użytkownicy mogą szybko zrozumieć, co oznaczają poszczególne kolory na mapie.\n\n"
    "5. Dostępność: Mapa jest zapisana w formacie HTML, co oznacza, że można ją łatwo otworzyć w "
    "przeglądarce internetowej. Dzięki temu każdy, kto otrzyma plik, może z niej korzystać od razu."
)

doc.add_heading('Opis danych', level=2)
doc.add_paragraph(
    "Do stworzenia mapy wykorzystałem dane o rezerwatach przyrody w Polsce, które zostały zapisane w "
    "formacie GeoJSON. Plik ten zawiera informacje o lokalizacji rezerwatów, ich typach oraz nazwach. "
    "Każdy rezerwatu jest przedstawiony jako poligon, co pozwala na dokładne odwzorowanie jego granic na mapie.\n\n"
    "Dane zostały pozyskane z oficjalnych źródeł (crfop.gdos.gov.pl), co zapewnia ich rzetelność i dokładność. W sumie na mapie "
    "znalazło się kilka różnych typów rezerwatów, takich jak rezerwaty krajobrazowe, rezerwaty leśne, "
    "czy rezerwaty fauny i flory. Każdy z tych typów ma swoje unikalne cechy i zasady ochrony, co czyni "
    "mapę cennym źródłem informacji dla osób zainteresowanych przyrodą."
)

doc.add_heading('Przykład mapy', level=2)
doc.add_paragraph(
    "Poniżej przedstawiam zrzut ekranu wybranego wariantu wyświetlenia mapy, na którym można zobaczyć kilka "
    "różnych typów rezerwatów w Polsce."
)
doc.add_picture(screenshot_path, width=Inches(6))
doc.add_paragraph(
    "Na zrzucie ekranu widać różne kolory reprezentujące różne typy rezerwatów. "
    "Każdy z nich jest zaznaczony na mapie, a po najechaniu na dany rezerwat pojawiają się informacje na "
    "jego temat np. rezerwaty krajobrazowe."
)

doc.add_heading('Jak mapa została stworzona', level=2)
doc.add_paragraph(
    "Tworzenie mapy zaczęło się od zebrania danych w formacie GeoJSON, które następnie wczytałem do programu "
    "w Pythonie. Wykorzystałem bibliotekę GeoPandas, która umożliwia efektywne zarządzanie danymi przestrzennymi, "
    "oraz Folium, która pozwala na tworzenie interaktywnych map.\n\n"
    "Kod został napisany tak, aby wczytywał dane z pliku GeoJSON, a następnie tworzył mapę centrowaną na "
    "Polsce. Każdy typ rezerwatu został przypisany do innego koloru, a następnie dodany do mapy w formie "
    "poligonów. Wykorzystano także funkcje, które umożliwiły dodanie interaktywnych 'tooltipów' i 'popupów', co "
    "wzbogaciło funkcjonalność mapy.\n\n"
    "Na końcu mapa została zapisana w formacie HTML, co pozwala na jej łatwe otwarcie w dowolnej przeglądarce "
    "internetowej."
)

doc.add_heading('Podsumowanie', level=2)
doc.add_paragraph(
    "Projekt stworzenia interaktywnej mapy rezerwatów przyrody w Polsce okazał się nie tylko "
    "wyzwaniem, ale także doświadczeniem w pracy z danymi przestrzennymi. Mapa dostarcza informacji o "
    "rezerwatach w przystępny i interaktywny sposób, co może przyczynić się do większej świadomości "
    "ekologicznej społeczeństwa. Mapa będzie w przyszłosci rozwijana. Ten oto opis mapy również "
    "powstał za pomocą skryptu zapisanego w IDE - Spyder."
)

file_path = os.path.join(folder_path, "opis_mapy.docx")
doc.save(file_path)

file_path
