# -*- coding: utf-8 -*-
"""
Created on Wed Sep 04 22:41:07 2024

@author: Maciej Wisniewski
"""

import geopandas as gpd
import folium
import random
import os

script_dir = os.path.dirname(__file__)
geojson_path = os.path.join(script_dir, 'rezerwaty.geojson')
gdf = gpd.read_file(geojson_path)

m = folium.Map(location=[52.2297, 21.0122], zoom_start=6, control_scale=True)

title_html = '''
     <h3 align="center" style="font-size: 24px; font-weight: bold; color: black;">Mapa rodzajów rezerwatów przyrody w Polsce</h3>
     '''
m.get_root().html.add_child(folium.Element(title_html))

unique_types = gdf['Rezerwaty_rezerwat'].unique()

def get_random_color():
    return "#{:06x}".format(random.randint(0, 0xFFFFFF))

colors = {rtype: get_random_color() for rtype in unique_types}

for reserve_type in unique_types:
    color = colors[reserve_type]  # Uzyskaj kolor dla danego typu
    
    group = gdf[gdf['Rezerwaty_rezerwat'] == reserve_type]
    
    feature_group = folium.FeatureGroup(name=reserve_type, show=False)
    
    for _, row in group.iterrows():
        folium.GeoJson(
            row['geometry'],
            name=row['nazwa'],
            style_function=lambda x, color=color: {
                'fillColor': color,
                'color': 'darkgray',
                'weight': 1,
                'fillOpacity': 0.5
            },
            tooltip=folium.Tooltip(
                f"Nazwa: {row['nazwa']}<br>Rodzaj: {row['Rezerwaty_rezerwat']}"
            ),
            popup=folium.Popup(
                f"{row['nazwa']}<br>Rodzaj: {row['Rezerwaty_rezerwat']}"
            )
        ).add_to(feature_group)
    
    feature_group.add_to(m)

folium.TileLayer(
    tiles='https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png',
    name='OpenStreetMap',
    attr='&copy; OpenStreetMap contributors'
).add_to(m)

folium.TileLayer(
    tiles='https://stamen-tiles-{s}.a.ssl.fastly.net/terrain/{z}/{x}/{y}.jpg',
    name='Stamen Terrain',
    attr='Map tiles by Stamen Design, under CC BY 3.0. Data by OpenStreetMap, under ODbL.'
).add_to(m)

folium.TileLayer(
    tiles='https://{s}.google.com/vt/lyrs=s&x={x}&y={y}&z={z}',
    name='Google Satellite',
    attr='&copy; Google',
    subdomains=['mt0', 'mt1', 'mt2', 'mt3']
).add_to(m)

def add_legend(map_object, colors_dict):
    legend_html = """
    <div style="position: fixed; 
                top: 10px; left: 10px; width: 150px; height: auto; 
                border:2px solid grey; z-index:9999; 
                font-size:14px; background-color:white;
                opacity: 0.7; padding: 10px;">
    <b>Legenda rezerwatów</b><br>
    """
    for reserve_type, color in colors_dict.items():
        legend_html += f'<i style="background:{color}; width: 12px; height: 12px; display:inline-block; margin-right: 5px;"></i> {reserve_type}<br>'
    legend_html += "</div>"
    
    map_object.get_root().html.add_child(folium.Element(legend_html))

add_legend(m, colors)

folium.LayerControl(collapsed=False).add_to(m)

m.save('rezerwaty_map.html')
